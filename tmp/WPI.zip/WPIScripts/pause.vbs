'Unique ID ligaments and windows script
Dim ID

On Error Resume Next
'If the parent object is htmlwindow2, then we are likely running in HTA otherwise we are in a script run from wscript.exe
If LCase(TypeName(me)) = "htmlwindow2" Then
    'Create an object to run the script
    Dim WshShell
    Set WshShell = CreateObject("WScript.Shell")
    'Get the path to the parent directory
    Dim ParentFolderName
    ParentFolderName = GetParentFolderName(document.location)

	'Added these lines for WPI usage
	ParentFolderName = Unescape(ParentFolderName)
	ParentFolderName = Replace(ParentFolderName,"file:///","")
	ParentFolderName = Replace(ParentFolderName,"file:","")
	ParentFolderName = Replace(ParentFolderName,"/","\")
	ParentFolderName = Replace(ParentFolderName,"\Common\","\WPIScripts\")

    'Add a WebBrowser object and register it in the collection Shell.Application.Windows
    Document.write "<OBJECT id='WebBrowser' classid='clsid:8856F961-340A-11D0-A96B-00C04FD705A2'><PARAM name=RegisterAsBrowser value=1></OBJECT>"
    'generates a random ID
    Randomize
    ID = CLng((10000000 - 100000 + 1) * Rnd + 100000)
    'Set as created WebBrowser ID
    WebBrowser.PutProperty "ID",CLng(ID)
    'Run the script and parameter passing our unique ID
    WshShell.Run "wscript.exe """ & ParentFolderName & "pause.vbs"" " & ID,0,False
Else
    'This is the running script
    'Check passed arguments
    If WScript.Arguments.Count < 1 Then WScript.Quit
    'Get ID
    ID = CLng(WScript.Arguments(0))
    Dim Windows
    Set Windows = CreateObject("Shell.Application").Windows
    'We are looking for a window with our ID
    For Each Window In Windows
        If Window.GetProperty("ID") = ID Then
            'Create a global variable within HTA
            Window.parent.parentWindow.execScript "Dim WScript","VBScript"
            'Gives it the WScript object
            Set Window.parent.parentWindow.WScript = WScript
            'Raises the initialization WScript
            Window.parent.parentWindow.wscript_initialized
            'We are waiting until the window is unloaded
            Exit For
        End If
    Next

    'We are waiting until the HTA window will close. Once that happens the type of Window will be the Object
    Do
        WScript.Sleep 100
    Loop Until VarType(Window) <> 8
End If    

Private Function GetParentFolderName(ByVal Path)
    Dim LastSlash1Pos,LastSlash2Pos
    LastSlash1Pos = InStrRev(Path,"\")
    LastSlash2Pos = InStrRev(Path,"/")
    if LastSlash1Pos < LastSlash2Pos Then LastSlash1Pos = LastSlash2Pos
    if LastSlash1Pos = 0 Then LastSlash1Pos = Len(Path)
    GetParentFolderName = Left(Path,LastSlash1Pos-1) & "\"
End Function
