mode con: cols=25 lines=5

md UserFiles

@echo off

MOVE /Y .\WPIScripts\config.js .\UserFiles\config.js
MOVE /Y .\WPIScripts\networkoptions.js .\UserFiles\networkoptions.js
MOVE /Y .\WPIScripts\themeoptions.js .\UserFiles\themeoptions.js
MOVE /Y .\WPIScripts\useroptions.js .\UserFiles\useroptions.js
MOVE /Y .\WPIScripts\windowoptions.js .\UserFiles\windowoptions.js

Exit